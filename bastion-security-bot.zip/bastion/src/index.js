require('dotenv').config();
const { createBot } = require('./bot');
const startDashboard = require('./dashboard/server');
const { pruneLogs } = require('./db');

if (!process.env.DISCORD_TOKEN) {
  console.error('Missing DISCORD_TOKEN. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const client = createBot();
startDashboard(client);

pruneLogs();
setInterval(pruneLogs, 6 * 60 * 60 * 1000).unref();

process.on('unhandledRejection', (e) => console.error('Unhandled rejection:', e));
client.login(process.env.DISCORD_TOKEN);
