const { db } = require('./db');

const ACTIONS = ['delete', 'timeout', 'kick', 'ban'];
const ENUMS = { action: ACTIONS, adderAction: ['none', 'timeout', 'kick', 'ban'] };
const ENUM_OVERRIDES = {
  antiRaid: { action: ['timeout', 'kick', 'ban'] },
  antiNuke: { action: ['strip', 'kick', 'ban'] },
  botAudit: { action: ['none', 'kick', 'ban'] },
};
const RANGES = {
  maxMessages: [2, 30],
  perSeconds: [2, 120],
  timeoutMinutes: [1, 40320], // Discord max is 28 days
  max: [2, 50],
  joinThreshold: [2, 100],
  minAccountAgeDays: [0, 365],
  raidMinutes: [1, 240],
  maxActions: [1, 20],
  timeoutAt: [1, 50],
  banAt: [2, 100],
  windowDays: [1, 90],
  adderTimeoutMinutes: [1, 40320],
  duplicateCount: [0, 20],
  capsPercent: [0, 100],
  maxEmojis: [0, 50],
};
const LOWER_LISTS = new Set(['words', 'blockedDomains', 'allowedDomains', 'commands']);
const ID_LISTS = new Set(['exemptRoleIds', 'exemptUserIds', 'allowedRoleIds', 'allowedUserIds', 'allowedBotIds', 'exemptChannelIds']);

const DEFAULTS = {
  logChannelId: null,
  exemptRoleIds: [],
  exemptUserIds: [],
  exemptChannelIds: [],
  escalation: { timeoutAt: 3, banAt: 6, windowDays: 7, timeoutMinutes: 60 },
  modules: {
    antiSpam: {
      enabled: true, maxMessages: 6, perSeconds: 5, duplicateCount: 4, maxEmojis: 15, capsPercent: 0,
      action: 'timeout', timeoutMinutes: 10,
    },
    mentionSpam: { enabled: true, max: 5, action: 'timeout', timeoutMinutes: 10 },
    linkFilter: {
      enabled: true, blockInvites: true, blockAllLinks: false, blockShorteners: false,
      blockedDomains: [], allowedDomains: [], action: 'delete', timeoutMinutes: 10,
    },
    restrictedCommands: {
      enabled: true, prefixes: ['!', '.', '?', '$', '-'], commands: [], detectSlash: true,
      allowAdmins: false, allowedRoleIds: [], allowedUserIds: [], action: 'timeout', timeoutMinutes: 30,
    },
    badWords: { enabled: false, words: [], matchInside: false, catchTricks: true, action: 'delete', timeoutMinutes: 10 },
    antiRaid: {
      enabled: true, joinThreshold: 8, perSeconds: 10, minAccountAgeDays: 3,
      raidMinutes: 15, action: 'kick', timeoutMinutes: 60,
    },
    botAudit: {
      enabled: true, action: 'none', allowedBotIds: [],
      kickBotsWithCommands: true, adderAction: 'timeout', adderTimeoutMinutes: 60,
    },
    antiNuke: {
      enabled: true, maxActions: 3, perSeconds: 30, action: 'kick',
      protectServerName: true, botsOnly: false,
    },
  },
};

function clamp(n, range, fallback) {
  n = Number(n);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(range[1], Math.max(range[0], Math.round(n)));
}

function cleanList(v, { lower = false, id = false } = {}) {
  if (!Array.isArray(v)) return [];
  const out = [];
  for (let x of v) {
    x = String(x).trim();
    if (!x || x.length > 100) continue;
    if (lower) x = x.toLowerCase();
    if (id && !/^\d{5,25}$/.test(x)) continue;
    if (!out.includes(x)) out.push(x);
    if (out.length >= 200) break;
  }
  return out;
}

function section(defaults, input, name) {
  const out = {};
  for (const [k, def] of Object.entries(defaults)) {
    const v = input && input[k] !== undefined ? input[k] : def;
    if (typeof def === 'boolean') out[k] = typeof v === 'boolean' ? v : def;
    else if (typeof def === 'number') out[k] = clamp(v, RANGES[k], def);
    else if (typeof def === 'string') {
      const allowed = (ENUM_OVERRIDES[name] || {})[k] || ENUMS[k];
      out[k] = allowed && allowed.includes(v) ? v : def;
    } else if (Array.isArray(def)) out[k] = cleanList(v, { lower: LOWER_LISTS.has(k), id: ID_LISTS.has(k) });
  }
  return out;
}

/** Builds a complete, validated settings object from any (possibly partial or hostile) input. */
function normalize(input = {}) {
  const out = {
    logChannelId: /^\d{5,25}$/.test(String(input.logChannelId ?? '')) ? String(input.logChannelId) : null,
    exemptRoleIds: cleanList(input.exemptRoleIds ?? DEFAULTS.exemptRoleIds, { id: true }),
    exemptUserIds: cleanList(input.exemptUserIds ?? DEFAULTS.exemptUserIds, { id: true }),
    exemptChannelIds: cleanList(input.exemptChannelIds ?? DEFAULTS.exemptChannelIds, { id: true }),
    escalation: section(DEFAULTS.escalation, input.escalation, 'escalation'),
    modules: {},
  };
  if (out.escalation.banAt <= out.escalation.timeoutAt) {
    out.escalation.banAt = Math.min(100, out.escalation.timeoutAt + 1);
  }
  for (const name of Object.keys(DEFAULTS.modules)) {
    out.modules[name] = section(DEFAULTS.modules[name], input.modules?.[name], name);
  }
  return out;
}

const cache = new Map();

function getSettings(guildId) {
  let s = cache.get(guildId);
  if (s) return s;
  const row = db.prepare('SELECT data FROM settings WHERE guild_id = ?').get(guildId);
  let parsed = {};
  try { parsed = row ? JSON.parse(row.data) : {}; } catch { /* corrupt row, fall back to defaults */ }
  s = normalize(parsed);
  cache.set(guildId, s);
  return s;
}

function saveSettings(guildId, input) {
  const s = normalize(input);
  db.prepare(
    'INSERT INTO settings(guild_id, data) VALUES(?, ?) ON CONFLICT(guild_id) DO UPDATE SET data = excluded.data'
  ).run(guildId, JSON.stringify(s));
  cache.set(guildId, s);
  return s;
}

module.exports = { getSettings, saveSettings, normalize, DEFAULTS };
